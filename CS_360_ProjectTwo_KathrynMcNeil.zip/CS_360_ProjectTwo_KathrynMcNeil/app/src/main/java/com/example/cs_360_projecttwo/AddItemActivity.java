package com.example.cs_360_projecttwo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import static com.example.cs_360_projecttwo.R.layout.new_item_modified;

public class AddItemActivity extends AppCompatActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new_item_modified);

        ActivityCompat.requestPermissions(AddItemActivity.this,new String[] {Manifest.permission.SEND_SMS}, PackageManager.PERMISSION_GRANTED);

        TextView btn = findViewById(R.id.goInventory);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AddItemActivity.this,DBActivity.class));
            }
        });
    }

}
