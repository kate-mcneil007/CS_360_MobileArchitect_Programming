package com.example.cs_360_projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import java.util.ArrayList;

public class DBActivity extends AppCompatActivity {

   private ArrayList<String> data = new ArrayList<String>();
   private ArrayList<String> data1 = new ArrayList<String>();
   private ArrayList<String> data2 = new ArrayList<String>();

   private TableLayout table;

   EditText ed1,ed2,ed3;
   Button button1;

   @Override
   protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.new_item);

      ed1 = findViewById(R.id.ed1);
      ed2 = findViewById(R.id.ed2);
      ed3 = findViewById(R.id.ed3);

      button1 = findViewById(R.id.addItem);

      button1.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
            add();
         }
      });
   }

   public void add() {
      String productName = ed1.getText().toString();
      int price = Integer.parseInt(ed2.getText().toString());
      int quantity = Integer.parseInt(ed3.getText().toString());

      data.add(productName);
      data1.add(String.valueOf(price));
      data2.add(String.valueOf(quantity));

      TableLayout table = (TableLayout) findViewById(R.id.table1);

      TableRow row = new TableRow(this);
      TextView column1 = new TextView(this);
      TextView column2 = new TextView(this);
      TextView column3 = new TextView(this);

      //int sum = 0;
      for (int i = 0; i < data.size(); i++) {
         String pName = data.get(i);
         String pPrice = data1.get(i);
         String pQuantity = data2.get(i);

         column1.setText(pName);
         column2.setText(pPrice);
         column3.setText(pQuantity);
      }

      row.addView(column1);
      row.addView(column2);
      row.addView(column3);
      table.addView(row);

      ed1.setText("");
      ed2.setText("");
      ed3.setText("");
   }
}
