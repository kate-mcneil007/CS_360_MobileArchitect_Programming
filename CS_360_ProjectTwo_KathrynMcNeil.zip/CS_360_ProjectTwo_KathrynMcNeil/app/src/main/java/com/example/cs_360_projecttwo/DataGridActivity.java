//package com.example.cs_360_projecttwo;
//
//import androidx.appcompat.app.AppCompatActivity;
//import android.Manifest;
//
//import android.widget.ArrayAdapter;
//import android.widget.EditText;
//import android.widget.ListView;
//
//import java.lang.reflect.Array;
//import java.util.ArrayList;
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.Button;
//import android.widget.TableLayout;
//import android.widget.TextView;
//
//public class DataGridActivity extends AppCompatActivity {
//    private ArrayList<String> data = new ArrayList<String>();
//    private ArrayList<String> data1 = new ArrayList<String>();
//    private ArrayList<String> data2 = new ArrayList<String>();
//
//    EditText ed1,ed2,ed3;
//    Button button1;
//
//    ListView listView;
//    @Override
//
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.data_grid_page);
//
//        ed1 = findViewById(R.id.ed1);
//        ed2 = findViewById(R.id.ed2);
//        ed3 = findViewById(R.id.ed3);
//
//        button1 = findViewById(R.id.addItem);
//
//        button1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                add();
//            }
//        });
//    }
//    public void add() {
//        listView = (ListView) findViewById(R.id.listview);
//
//        String productName = ed1.getText().toString();
//        int price = Integer.parseInt(ed2.getText().toString());
//        int quantity = Integer.parseInt(ed3.getText().toString());
//
//        listView = (ListView) findViewById(R.id.listview);
//
//        ArrayList<String> arrayList = new ArrayList<>();
//
//        data.add(productName);
//        data1.add(String.valueOf(price));
//        data2.add(String.valueOf(quantity));
//
//        arrayList.add("Hello");
//        arrayList.add("Product: " + data + " " + "Price: " + data1 + " " + "Quantity: " + data2);
//
//        ed1.setText("");
//        ed2.setText("");
//        ed3.setText("");
//
//
//        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,arrayList);
//
//        listView.setAdapter(arrayAdapter);
//    }
//}